package com.bikeonrent.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class User_profile {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long user_id;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name= "profile_id")
	private Profile profile;
	
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name= "address")
	private List<Address> address;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name= "aadharCard")
	private AadharCard aadharCard;
	
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name= "feedback")
	private List<Feedback> feedback;

	public long getUser_id() {
		return user_id;
	}

	public void setUser_id(long user_id) {
		this.user_id = user_id;
	}

	public Profile getProfile() {
		return profile;
	}

	public void setProfile(Profile profile) {
		this.profile = profile;
	}

	public List<Address> getAddress() {
		return address;
	}

	public void setAddress(List<Address> address) {
		this.address = address;
	}

	public AadharCard getAadharCard() {
		return aadharCard;
	}

	public void setAadharCard(AadharCard aadharCard) {
		this.aadharCard = aadharCard;
	}

	public List<Feedback> getFeedback() {
		return feedback;
	}

	public void setFeedback(List<Feedback> feedback) {
		this.feedback = feedback;
	}
	
	
	
}
