package com.bikeonrent.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Shop_Detail {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long shop_id;
	private String shop_name;
	private String shop_lincense;
	public long getShop_id() {
		return shop_id;
	}
	public void setShop_id(long shop_id) {
		this.shop_id = shop_id;
	}
	public String getShop_name() {
		return shop_name;
	}
	public void setShop_name(String shop_name) {
		this.shop_name = shop_name;
	}
	public String getShop_lincense() {
		return shop_lincense;
	}
	public void setShop_lincense(String shop_lincense) {
		this.shop_lincense = shop_lincense;
	}
	
	

}
