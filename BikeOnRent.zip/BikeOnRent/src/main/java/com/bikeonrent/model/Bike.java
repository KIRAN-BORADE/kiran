package com.bikeonrent.model;

import java.sql.Blob;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class Bike {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long bike_id;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="bike_model")
	private Bike_Model_Detail bike_model;
	private Blob bike_image;
	private int bike_cc;
	private long bike_no;
	private String bike_average;
	private long bike_count;
	public long getBike_id() {
		return bike_id;
	}
	public void setBike_id(long bike_id) {
		this.bike_id = bike_id;
	}
	
	public Blob getBike_image() {
		return bike_image;
	}
	public void setBike_image(Blob bike_image) {
		this.bike_image = bike_image;
	}
	public int getBike_cc() {
		return bike_cc;
	}
	public void setBike_cc(int bike_cc) {
		this.bike_cc = bike_cc;
	}
	public long getBike_no() {
		return bike_no;
	}
	public void setBike_no(long bike_no) {
		this.bike_no = bike_no;
	}
	public String getBike_average() {
		return bike_average;
	}
	public void setBike_average(String bike_average) {
		this.bike_average = bike_average;
	}
	public long getBike_count() {
		return bike_count;
	}
	public void setBike_count(long bike_count) {
		this.bike_count = bike_count;
	}
	public Bike_Model_Detail getBike_model() {
		return bike_model;
	}
	public void setBike_model(Bike_Model_Detail bike_model) {
		this.bike_model = bike_model;
	}
	
	
}
