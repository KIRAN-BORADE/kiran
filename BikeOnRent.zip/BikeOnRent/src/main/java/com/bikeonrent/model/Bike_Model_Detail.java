package com.bikeonrent.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Bike_Model_Detail {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long bike_model_id;
	private String bike_model_name;
	private String bike_model_type;
	private String bike_model_year;
	
	public long getBike_model_id() {
		return bike_model_id;
	}
	public void setBike_model_id(long bike_model_id) {
		this.bike_model_id = bike_model_id;
	}
	public String getBike_model_name() {
		return bike_model_name;
	}
	public void setBike_model_name(String bike_model_name) {
		this.bike_model_name = bike_model_name;
	}
	public String getBike_model_type() {
		return bike_model_type;
	}
	public void setBike_model_type(String bike_model_type) {
		this.bike_model_type = bike_model_type;
	}
	public String getBike_model_year() {
		return bike_model_year;
	}
	public void setBike_model_year(String bike_model_year) {
		this.bike_model_year = bike_model_year;
	}
	
	
	

}
