package com.bikeonrent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BikeOnRentApplication {

	public static void main(String[] args) {
		SpringApplication.run(BikeOnRentApplication.class, args);
	}

}
